<?php
class Constants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=sql.draconiclabs.ca;dbname=bowlingtournament";
    public static $MYSQL_USERNAME = "bulleyebowling";
    public static $MYSQL_PASSWORD = "bulleyebowling";
}
?>