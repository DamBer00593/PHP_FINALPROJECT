<?php
require_once dirname(__DIR__, 1) . '/api.bulleye.party/connectionManager.php';
require_once dirname(__DIR__, 1) . '/api.bulleye.party/constants.php';
require_once dirname(__DIR__, 1) . '/api.bulleye.party/DataAccessor.php';


$method = $_SERVER['REQUEST_METHOD'];


/*
End points defined
/team -  bulk GET
/team/id - GET
/team/id - POST, {teamID, teamName}
/team - POST, bulk post not supported
/team/id - PUT, {teamID, teamName}
/team - PUT, bulk put not supported
/team/id - DELETE-+
/team - DELETE, bulk delete not supported

/player - bulk GET
/player/id - GET
/player/id - POST, {playerID, teamID, firstName, lastName, hometown, province}
/player - POST, bulk post not supported
/player/id - PUT, {playerID, teamID, firstName, lastName, hometown, province}
/player - PUT, bulk put not supported
/player/id - DELETE
/player - DELETE, bulk delete not supported

/game - bulk GET
/game/id - GET
/game/id - POST, {gameID, matchID, gameNumber, gameStateID, score, balls, playerID}
/game - POST, bulk post not supported
/game/id - PUT, {gameID, matchID, gameNumber, gameStateID, score, balls, playerID}
/game - PUT, bulk put not supported
/game/id - DELETE
/game - DELETE, bulk delete not supported

/match - bulk GET
/match/id - GET
/match/id - POST, {matchID, roundID, matchGroup, teamID, score, ranking}
/match - POST, bulk post not supported
/match/id - PUT, {matchID, roundID, matchGroup, teamID, score, ranking}
/match - PUT, bulk put not supported
/match/id - DELETE
/match - DELETE, bulk delete not supported

*/

try {
    $cm = new ConnectionManager(Constants::$MYSQL_CONNECTION_STRING, Constants::$MYSQL_USERNAME, Constants::$MYSQL_PASSWORD);
    $dAccessor = new DataAccessor($cm->getConnection());
    $action = $_GET["action"];
    if ($method === "GET") {
        doGet($dAccessor,$action);
    } else if ($method === "POST") {
        doPost($dAccessor,$action);
    } else if ($method === "DELETE") {
        doDelete($dAccessor,$action);
    } else if ($method === "PUT") {
        doPut($dAccessor,$action);
    } else {
        sendResponse(405, null, "method not allowed");
    }
} catch (Exception $e) {
    sendResponse(500, null, "ERROR " . $e->getMessage());
} finally {
    if (!is_null($cm)) {
        $cm->closeConnection();
    }
}

function doGet($dAccessor,$action)
{
    

    // individual
    if (isset($_GET['itemid'])) {
        $itemID = $_GET['ID'];
        if($action == "team"){
            $dAccessor->getTeamByID($itemID);
        } else if ($action == "player"){
            $dAccessor->getPlayerByID($itemID);
        } else if($action == "game"){
            $dAccessor->getGameByID($itemID);
        } else if($action == "match"){
            $dAccessor->getMatchByID($itemID);
        }

        sendResponse(405, null, "bulk GETs not allowed");
    }
    // collection
    else {
        if($action == "team"){
            $res = $dAccessor->getAllTeams();
            sendResponse(200, $res, null);
        } else if ($action == "player"){
            $res = $dAccessor->getAllPlayers();
            sendResponse(200, $res, null);
        } else if($action == "game"){
            $res = $dAccessor->getAllGames();
            sendResponse(200, $res, null);
        } else if($action == "match"){
            $res = $dAccessor->getAllMatches();
            sendResponse(200, $res, null);
        } else{
            sendResponse(405, null, "Something went horribily wrong"); 
        }


/*
        try {
            $results = $dAccessor->getAllItems();
            if (count($results) > 0) {
                $results = json_encode($results, JSON_NUMERIC_CHECK);
                sendResponse(200, $results, null);
            } else {
                sendResponse(404, null, "could not retrieve items");
            }
        } catch (Exception $e) {
            sendResponse(500, null, "ERROR " . $e->getMessage());
        }*/
    }
}

function doDelete($dAccessor)
{
    if (isset($_GET['itemid'])) {
        $itemID = $_GET['itemid'];
        // Only the ID of the item matters for a delete,
        // but the accessor expects an object, 
        // so we need a dummy object.
        $menuItemObj = new MenuItem($itemID, "dummyCat", "dummyDesc", 8, 0);

        // delete the object from DB
        $success = $dAccessor->deleteItem($menuItemObj);
        if ($success) {
            sendResponse(200, $success, null);
        } else {
            sendResponse(404, null, "could not delete item - it does not exist");
        }
    } else {
        // Bulk deletes not implemented.
        sendResponse(405, null, "bulk DELETEs not allowed");
    }
}

// aka CREATE
function doPost($dAccessor)
{
    if (isset($_GET['itemid'])) {
        // The details of the item to insert will be in the request body.
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);

        try {
            // create a MenuItem object
            $menuItemObj = new MenuItem($contents['itemID'], $contents['itemCategoryID'], $contents['description'], $contents['price'], $contents['vegetarian']);

            // add the object to DB
            $success = $dAccessor->insertItem($menuItemObj);
            if ($success) {
                sendResponse(201, $success, null);
            } else {
                sendResponse(409, null, "could not insert item - it already exists");
            }
        } catch (Exception $e) {
            sendResponse(400, null, $e->getMessage());
        }
    } else {
        // Bulk inserts not implemented.
        sendResponse(405, null, "bulk INSERTs not allowed");
    }
}

// aka UPDATE
function doPut($dAccessor)
{
    if (isset($_GET['itemid'])) {
        // The details of the item to update will be in the request body.
        $body = file_get_contents('php://input');
        $contents = json_decode($body, true);

        try {
            // create a MenuItem object
            $menuItemObj = new MenuItem($contents['itemID'], $contents['itemCategoryID'], $contents['description'], $contents['price'], $contents['vegetarian']);

            // update the object in the  DB
            $success = $dAccessor->updateItem($menuItemObj);
            if ($success) {
                sendResponse(200, $success, null);
            } else {
                sendResponse(404, null, "could not update item - it does not exist");
            }
        } catch (Exception $e) {
            sendResponse(400, null, $e->getMessage());
        }
    } else {
        // Bulk updates not implemented.
        sendResponse(405, null, "bulk UPDATEs not allowed");
    }
}

function sendResponse($statusCode, $data, $error)
{
    header("Content-Type: application/json");
    http_response_code($statusCode);
    $resp = ['data' => $data, 'error' => $error];
    echo json_encode($resp, JSON_NUMERIC_CHECK);
}